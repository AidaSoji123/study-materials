from django.contrib import admin
from . models import Place_details,Founder

# Register your models here.
admin.site.register(Place_details)
admin.site.register(Founder)